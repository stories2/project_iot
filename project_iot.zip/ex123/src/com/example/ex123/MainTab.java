package com.example.ex123;

import android.app.Activity;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TabHost;
import android.app.TabActivity;

public class MainTab extends TabActivity implements Runnable{

	TabHost tab_host;
	TabHost.TabSpec tabs;
	public static socket_thread thread;
	public static String android_codename,sdk_level,phone_number,imei,imsi,
	display_country,country,language,mac;
	public static int sdk_int,query_limit = 100;	
	Intent intent;
	public static String[][] sql_query = new String[100][3];
	Thread init_thread;
	WifiManager wifi_manager;
	WifiInfo wifi_info;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.product_list_view);
		
		init();
	}
	
	public void init()
	{
		setTitle("");
		
		int i,t;
		for(i=0;i<query_limit;i+=1)
		{
			for(t=0;t<3;t+=1)
			{
				sql_query[i][t] = "";
			}
		}
		
		thread = new socket_thread(8080);
		thread.start();
		
		wifi_manager = (WifiManager)getSystemService(WIFI_SERVICE);
		wifi_info = wifi_manager.getConnectionInfo();
		mac = wifi_info.getMacAddress();
		
		tab_host = getTabHost();
		
		tabs = tab_host.newTabSpec("List Product");
		tabs.setIndicator("��ϵ� ��ġ��");
		Intent setting_tab = new Intent(getApplicationContext(),list.class);
		tabs.setContent(setting_tab);
		tab_host.addTab(tabs);
		
		tabs = tab_host.newTabSpec("Add Product");
		tabs.setIndicator("��ġ �߰�");
		setting_tab = new Intent(getApplicationContext(),add.class);
		tabs.setContent(setting_tab);
		tab_host.addTab(tabs);
		
		tabs = tab_host.newTabSpec("App Info");
		tabs.setIndicator("�� ����");
		setting_tab = new Intent(getApplicationContext(),info.class);
		tabs.setContent(setting_tab);
		tab_host.addTab(tabs);
		
		intent = getIntent();
		try
		{
			android_codename = intent.getStringExtra("android codename");
			sdk_level = intent.getStringExtra("sdk level");
			phone_number = intent.getStringExtra("phone number");
			imei = intent.getStringExtra("imei");
			imsi = intent.getStringExtra("imsi");
			display_country = intent.getStringExtra("display country");
			country = intent.getStringExtra("country");
			language = intent.getStringExtra("language");
			sdk_int = intent.getExtras().getInt("sdk int");
			
			Log.d("ex123","imei : "+imei+" imsi : "+imsi+" phone number : "+phone_number+" android codename : "+android_codename+
					" sdk lv."+sdk_level+" sdk int : "+sdk_int+" display country : "+display_country+" country : "+country+
					" language : "+language);
			

			init_thread = new Thread(this);
			init_thread.start();
		}
		catch(Exception e)
		{
			Log.d("ex123","Error : <MainTab> "+e.getMessage()); 
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		int sql_order_number;
		try
		{

			String query = "insert into user_list values('"+imei+"','"+mac+"','"+sdk_level+"','"+phone_number+"','"+language+"','"+
					country+"',1);";
			sql_order_number = MainTab.thread.execute_query(query);
			
			Log.d("ex123","order number #"+sql_order_number+" query : "+query);
			while(true)
			{
				try
				{
					Thread.sleep(100);
					if(MainTab.sql_query[sql_order_number][2].equals("")!=true)
					{
						//Log.d("ex123","Client <- Server : "+MainTab.sql_query[sql_order_number][2]);
						MainTab.sql_query[sql_order_number][2] = "";
						break;
					}
				}
				catch(Exception e)
				{
					Log.d("ex123","Error : "+e.getMessage()); 
				}
			}
		}
		catch(Exception e)
		{
			Log.d("ex123","Error : "+e.getMessage()); 
		}
	}
}
