package com.example.ex123;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class product_info extends Activity {
	
	Intent intent;
	String control_target,mac;
	WebView web_view;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.product_info_ui);
				
		init();
	}
	
	public void init()
	{
		web_view = (WebView)findViewById(R.id.web_view);
		intent = getIntent();
		control_target = intent.getStringExtra("product_id");
		mac = MainTab.mac;
		Log.d("ex123","mac : "+mac+" target mac : "+control_target);
		web_view.getSettings().setJavaScriptEnabled(true);
		
		web_view.loadUrl("http://stories2.ggu.la/iot_control.php?client="+mac+"&product="+control_target);		
		web_view.setWebViewClient(new web_view_client());
	}
	
	public class web_view_client extends WebViewClient
	{
		public boolean shouldOverrideUrlLoading(WebView view, String url)
		{
			view.loadUrl(url);
			return true;
		}
	}
}
