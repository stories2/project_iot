package com.example.ex123;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class add extends Activity implements Runnable{

	CheckBox[] chk_box;
	Button btn_rdy;
	EditText[] etxt_product;
	String[][] log_box;
	int r,f,limit;
	boolean update_flag;
	Thread thread;
	static Context context;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add);
		
		
		init();
		
		btn_rdy.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				update_flag = true;
				check_exception();
			}
		});
		
		chk_box[1].setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int i;
				for(i=1;i<=3;i+=1)
				{
					if(chk_box[i].isChecked() == true && i!= 1)
					{
						chk_box[i].setChecked(false);
					}
				}
			}
		});
		
		chk_box[2].setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int i;
				for(i=1;i<=3;i+=1)
				{
					if(chk_box[i].isChecked() == true && i!= 2)
					{
						chk_box[i].setChecked(false);
					}
				}
			}
		});
		
		chk_box[3].setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int i;
				for(i=1;i<=3;i+=1)
				{
					if(chk_box[i].isChecked() == true && i!= 3)
					{
						chk_box[i].setChecked(false);
					}
				}
			}
		});
	}
	
	public void check_exception()
	{
		int i;
		boolean error = false;
		String[] product_number = new String[3];
		int how_can_u_get_that = 0;
		for(i=1;i<=2;i+=1)
		{
			product_number[i] = "";
			product_number[i] = etxt_product[i].getText().toString();
			if(product_number[i].equals(""))
			{
				error = true;
			}
		}	
		for(i=1;i<=3;i+=1)
		{
			if(chk_box[i].isChecked() == true)
			{
				how_can_u_get_that = i ;
				break;
			}
		}
		if(how_can_u_get_that == 0)
		{
			error = true;
		}
		if(error == false)
		{
			update_flag = true;
			log_box[r][1] = "" + MainTab.thread.execute_query("insert into user_product value('"+MainTab.mac+"','"+product_number[1]+"');");
			log_box[r][2] = "insert into user_product value('"+MainTab.mac+"','"+product_number[1]+"');";
			r+=1;
			log_box[r][1] = "" + MainTab.thread.execute_query("insert into user_product value('"+MainTab.mac+"','"+product_number[2]+"');");
			log_box[r][2] = "insert into user_product value('"+MainTab.mac+"','"+product_number[2]+"');";
			r+=1;
		}
	}
	
	public void init()
	{
		int i,t;
		limit = 10;
		r = 0;
		f = 0;
		update_flag = false;
		log_box = new String[limit][4];
		for(i=0;i<limit;i+=1)
		{
			for(t=0;t<4;t+=1)
			{
				log_box[i][t] = "";
			}
		}
		
		context = this.getApplicationContext();
		
		thread = new Thread(this);
		thread.start();
		
		chk_box = new CheckBox[4];
		chk_box[1] = (CheckBox)findViewById(R.id.chk_1);
		chk_box[2] = (CheckBox)findViewById(R.id.chk_2);
		chk_box[3] = (CheckBox)findViewById(R.id.chk_3);
		
		etxt_product = new EditText[3];
		etxt_product[1] = (EditText)findViewById(R.id.etxt_product_1);
		etxt_product[2] = (EditText)findViewById(R.id.etxt_product_2);
		
		btn_rdy = (Button)findViewById(R.id.btn_rdy);
		
		Log.d("ex123","Add View init ok");
	}
	
	static Handler handler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			Toast.makeText(context, msg.getData().getString("update"), Toast.LENGTH_SHORT).show();
			Log.d("ex123","toast ok");
		}
	};
	
	public static void update(String update_string)
	{
		Bundle bundle = new Bundle();
		bundle.putString("update",update_string);
		Message msg = handler.obtainMessage();
		msg.setData(bundle);
		handler.sendMessage(msg);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true)
		{
			try
			{
				if(r>f)
				{/*
					if(log_box[(f+1)%limit][3].equals("")!=true)
					{
						Log.d("ex123","add Client <- Server : "+log_box[(f+1)%limit][3]);
						f+=1;
					}*/
					if(MainTab.sql_query[Integer.parseInt(log_box[f%limit][1])][2].equals("")!=true)
					{
						log_box[f%limit][3] = MainTab.sql_query[Integer.parseInt(log_box[f%limit][1])][2];
						MainTab.sql_query[Integer.parseInt(log_box[f%limit][1])][2] = "";
						MainTab.sql_query[Integer.parseInt(log_box[f%limit][1])][1] = "";
						Log.d("ex123","add order ok #"+log_box[f%limit][1] + " "+log_box[f%limit][3]);
						f+=1;
						
					}
					//sql_query
				}
				else
				{
					if(update_flag == true)
					{
						update_flag = false;
						Log.d("ex123","f : "+f);
						if(log_box[(f-1)%limit][3].contains("Error") || log_box[(f-2)%limit][3].contains("Error"))
						{
							log_box[(f-2)%limit][3]= "";
							log_box[(f-1)%limit][3]= "";
							Log.d("ex123","add fail but request is exist");
							update("������� ������ ������ϴ�");
						}
						else
						{
							Log.d("ex123","add ok");
							update("��Ⱑ ���������� ��ϵǾ����ϴ�");
						}
					}
				}
				Thread.sleep(1);
			}
			catch(Exception e)
			{
				Log.d("ex123","Error : "+e.getMessage());
				break;
			}
		}
	}
}
