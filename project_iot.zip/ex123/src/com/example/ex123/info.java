package com.example.ex123;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;

public class info extends Activity implements Runnable{

	static TextView txt_update,txt_log_view;
	int order_number = -1;
	static Bundle bundle;
	Thread thread;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.info);
				
		init();
	}
	static Handler handler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			txt_update.setText(msg.getData().getString("app_ver"));
			if(msg.getData().getString("permission").equals("1"))
			{
				txt_log_view.setTextColor(Color.parseColor("#ff76cd7c"));	
			}
			else if(msg.getData().getString("permission").equals("2"))
			{
				txt_log_view.setTextColor(Color.parseColor("#ffecf15e"));
			}
			else if(msg.getData().getString("permission").equals("3"))
			{
				txt_log_view.setTextColor(Color.parseColor("#fff1665e"));
			}
			txt_log_view.setText(msg.getData().getString("head")+"\n"+msg.getData().getString("body")+"\n-"+msg.getData().getString("date"));
			txt_log_view.setTextColor(Color.parseColor("#ffffffff"));
		}
	};
	
	public static void update(String update_string)
	{
		parsing(update_string);
		Message msg = handler.obtainMessage();
		msg.setData(bundle);
		handler.sendMessage(msg);
	}
	
	public static void parsing(String update_string)
	{
		bundle = new Bundle();
		
		int i,t=0,str_length = update_string.length();
		String[] data = new String[5];
		
		for(i=0;i<5;i+=1)
		{
			data[i] = "";
		}
		
		for(i=0;i<str_length;i+=1)
		{
			if(update_string.charAt(i) == ';')
			{
				break;
			}
			if(update_string.charAt(i) != '|')
			{
				data[t] = data[t] + "" + update_string.charAt(i);
			}
			else
			{
				t += 1;
			}
		}
		Log.d("ex123","parse ok head : "+data[0]+" body : "+data[1]+" app_ver : "+data[2]+" date : "+data[3]+" permission : "+data[4]);
		bundle.putString("head",data[0]);
		bundle.putString("body", data[1]);
		bundle.putString("date", data[3]);
		bundle.putString("app_ver", data[2]);
		bundle.putString("permission", data[4]);
	}
	
	public void init()
	{
		thread = new Thread(this);
		thread.start();
		String query = "select * from app_notice;";
		
		txt_update = (TextView)findViewById(R.id.txt_update);
		txt_log_view = (TextView)findViewById(R.id.txt_log_view);
		
		order_number = MainTab.thread.execute_query(query);
		
		Log.d("ex123","Info View init ok");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true)
		{
			try
			{
				if(order_number!= -1)
				{
					if(MainTab.sql_query[order_number][2].equals("")!=true )
					{
						update(MainTab.sql_query[order_number][2]);
						MainTab.sql_query[order_number][2] = "";
					}
				}
				Thread.sleep(1);
			}
			catch(Exception e)
			{
				Log.d("ex123","Error : "+e.getMessage());
				break;
			}
		}
	}
}
