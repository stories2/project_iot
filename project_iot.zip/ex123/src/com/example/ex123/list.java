package com.example.ex123;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class list extends Activity implements Runnable{

	ListView list_product;
	static ArrayAdapter<String> adapter;
	Thread thread;
	static int order_number,update_ui_number;
	static TextView txt_none;
	static Bundle bundle;
	String[][] order_log;//0 : ���� ��� ��ȣ , 1 : ���ɾ� , 2 : ui ���� ��ȣ 
	int r,f,limit = 10,del_item = 0;
	/*
	 * 
	public static String android_codename,sdk_level,phone_number,imei,imsi,
	display_country,country,language;
	public static int sdk_int;	
	*/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list);
		
		init();
		
		list_product.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(getApplicationContext(),product_info.class);
				intent.putExtra("product_id",adapter.getItem(arg2));
				startActivity(intent);
			}
		});
		list_product.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				del_item = arg2;
				AlertDialog.Builder alert_confirm = new AlertDialog.Builder(list.this);
				alert_confirm.setMessage("�ش� ��ǰ�� �����Ͻðڽ��ϱ�?").setCancelable(false).setPositiveButton("��",
				new DialogInterface.OnClickListener() {
				    @Override
				    public void onClick(DialogInterface dialog, int which) {
				        // 'YES'
				    	//"DELETE FROM user_product WHERE ProductMac = \'"+list_product.getItemAtPosition(arg2)+"\'";
						order_number = MainTab.thread.execute_query("DELETE FROM user_product WHERE ProductMac = \'"+list_product.getItemAtPosition(del_item)+"\'");
						order_log[r%limit][0] = ""+order_number;
						order_log[r%limit][1] = "DELETE FROM user_product WHERE ProductMac = \'"+list_product.getItemAtPosition(del_item)+"\'";
						order_log[r%limit][2] = "3";
						r+=1;
						adapter.clear();
						adapter.notifyDataSetChanged();
						order_number = MainTab.thread.execute_query("select * from user_product where Imei = '"+MainTab.mac+"';");
						order_log[r%limit][0] = ""+order_number;
						order_log[r%limit][1] = "select * from user_product where Imei = '"+MainTab.mac+"';";
						order_log[r%limit][2] = "2";
						r+=1;
				    }
				}).setNegativeButton("�ƴϿ�",
				new DialogInterface.OnClickListener() {
				    @Override
				    public void onClick(DialogInterface dialog, int which) {
				        // 'No'
				    return;
				    }
				});
				AlertDialog alert = alert_confirm.create();
				alert.show();
				return true;
			}
		});
	}
	
	public void init()
	{
		order_log = new String[limit][4];
		int i,t;
		r = 0;
		f = 0;
		for(i=0;i<limit;i+=1)
		{
			for(t=0;t<4;t+=1)
			{
				order_log[i][t] = "";
			}
		}
		try
		{
			txt_none = (TextView)findViewById(R.id.txt_none);
			String query = "select * from user_product where Imei = '"+MainTab.mac+"';";
			order_number = MainTab.thread.execute_query(query);
			order_log[r%limit][0] = ""+order_number;
			order_log[r%limit][1] = query;
			order_log[r%limit][2] = "2";
			r+=1;
			Log.d("ex123","list : #"+order_number+" : "+query);
		}
		catch(Exception e)
		{
			Log.d("ex123","Error : "+e.getMessage());
		}
		thread_control();
		
		adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1);
		list_product = (ListView)findViewById(R.id.list_product);
		list_product.setAdapter(adapter);
		
		Log.d("ex123","list view init ok");
	}
	
	static Handler handler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			if(msg.getData().getInt("update_what") == 1)
			{
				txt_none.setText(msg.getData().getString("update"));
			}
			if(msg.getData().getInt("update_what") == 2)
			{
				txt_none.setText("");
				String temp = "";
				//Log.d("ex123","start parsing length : "+msg.getData().getString("update").length()+" "+msg.getData().getString("update"));
				int i,str_length = msg.getData().getString("update").length(),last_point = 0,bar = 0;
				for(i=str_length-1;i>=0;i-=1)
				{
					if(msg.getData().getString("update").charAt(i) == ';')
					{
						last_point = i;
					}
				}
				Log.d("ex123","last point : "+last_point);
				adapter.clear();
				adapter.notifyDataSetChanged();
				for(i=0;i<msg.getData().getString("update").length();i+=1)
				{
					if(bar%2 == 1 && msg.getData().getString("update").charAt(i) != '|')
					{
						temp = temp + "" + msg.getData().getString("update").charAt(i);
					}
					if(msg.getData().getString("update").charAt(i) == '|')
					{
						if(bar%2 == 1)
						{
							adapter.add(temp);
							adapter.notifyDataSetChanged();
							Log.d("ex123","list added : "+temp);
							temp = "";
						}
						bar += 1;
					}
				}
			}
		}
	};
	
	public static void update(String update_string,int update_ui)
	{
		bundle = new Bundle();
		bundle.putString("update",update_string);
		bundle.putInt("update_what", update_ui);
		Message msg = handler.obtainMessage();
		msg.setData(bundle);
		handler.sendMessage(msg);
	}
	
	public void thread_control()
	{
		try
		{
			thread = new Thread(this);
			thread.start();
			//thread.join();
		}
		catch(Exception e)
		{
			Log.d("ex123","Error : "+e.getMessage());
		}
		//thread.interrupt();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		int i,t,timer = 0,update_time = 5000;
		try
		{
			while(true)
			{
				try
				{
					timer+=1;
					if(timer % update_time == 0)
					{
						Log.d("ex123","list view auto update");
						String query = "select * from user_product where Imei = '"+MainTab.mac+"';";
						order_number = MainTab.thread.execute_query(query);
						order_log[r%limit][0] = ""+order_number;
						order_log[r%limit][1] = query;
						order_log[r%limit][2] = "2";
						r+=1;
					}
					/*if(MainTab.sql_query[order_number][2].equals("")!=true)
					{
						//Log.d("ex123","Client <- Server : "+MainTab.sql_query[order_number][2]);
						for(i=0;i<limit;i+=1)
						{
							if(Integer.parseInt(order_log[i][0]) == order_number)
							{
								if(order_log[i][2].equals("1"))
								{
									if(MainTab.sql_query[order_number][2].contains("nothing to show"))
									{
										Log.d("ex123","nothing to show");
										update("���� ��ϵ� ��ġ�� �����ϴ�",1);
										for(t=0;t<4;t+=1)
										{
											order_log[i][t] = "";
										}
									}
									else
									{
										Log.d("ex123","product exist");
										update(MainTab.sql_query[order_number][2],2);
										for(t=0;t<4;t+=1)
										{
											order_log[i][t] = "";
										}
									}
								}
								else
								{
									
								}
								break;
							}
						}
						
						MainTab.sql_query[order_number][2] = "";
						
						break;
					}*/
					if(r>f)
					{
						if(MainTab.sql_query[Integer.parseInt(order_log[f%limit][0])][2].equals("") != true)
						{
							Log.d("ex123","list class get data");
							if(MainTab.sql_query[Integer.parseInt(order_log[f%limit][0])][2].contains("Error"))
							{
								Log.d("ex123","List class error : "+MainTab.sql_query[Integer.parseInt(order_log[f%limit][0])][2]);
							}
							else if(MainTab.sql_query[Integer.parseInt(order_log[f%limit][0])][2].contains("nothing to show"))
							{
								Log.d("ex123","List class nothing to show");
								update("���� ��ϵ� ��ġ�� �����ϴ�",1);
							}
							else if(order_log[f%limit][2].equals("2"))//list update
							{
								Log.d("ex123","list view rdy to update");
								update(MainTab.sql_query[Integer.parseInt(order_log[f%limit][0])][2],Integer.parseInt(order_log[f%limit][2]));
							}
							else if(order_log[f%limit][2].equals("3"))//delete item
							{
								update(MainTab.sql_query[Integer.parseInt(order_log[f%limit][0])][2],Integer.parseInt(order_log[f%limit][2]));
							}
							MainTab.sql_query[Integer.parseInt(order_log[f%limit][0])][2] = "";
							MainTab.sql_query[Integer.parseInt(order_log[f%limit][0])][1] = "";
							for(i=0;i<=2;i+=1)
							{
								order_log[f%limit][i] = "";
							}
							f+=1;
						}
					}
					Thread.sleep(1);
				}
				catch(Exception e)
				{
					Log.d("ex123","Error Thread Process : "+e.getMessage());
				}
			}
			//Thread.interrupted();
		}	
		catch(Exception e)
		{
			Log.d("ex123","Error Thread : "+e.getMessage());
		}
	}
}
