package com.example.ex123;

import java.util.Locale;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;

public class MainActivity extends Activity {

	String android_codename,sdk_level,phone_number,imei,imsi,
	display_country,country,language;
	int sdk_int;	
	TelephonyManager tel;
	Locale local;
	Intent intent;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		init();
		go_next();		
	}
	
	void go_next()
	{
		intent = new Intent(getApplicationContext(),MainTab.class);
		intent.putExtra("android codename", android_codename);
		intent.putExtra("sdk level", sdk_level);
		intent.putExtra("phone number", phone_number);
		intent.putExtra("imei", imei);
		intent.putExtra("imsi", imsi);
		intent.putExtra("display country", display_country);
		intent.putExtra("country", country);
		intent.putExtra("language", language);
		intent.putExtra("sdk int", sdk_int);
		startActivity(intent);
		finish();
	}
	
	static Handler handler = new Handler()
	{
		public void handleMessage(Message msg)
		{
		}
	};
	
	public static void update(String update_string)
	{
		Message msg = handler.obtainMessage();
		handler.sendMessage(msg);
	}
	
	public void init()
	{
		try
		{
			setTitle("");
			
			tel = (TelephonyManager)getSystemService(TELEPHONY_SERVICE);
			local = getResources().getConfiguration().locale;
			
			display_country = local.getDisplayCountry();
			country = local.getCountry();
			language = local.getLanguage();
			imei = tel.getDeviceId();
			imsi = tel.getSubscriberId();
			phone_number = tel.getLine1Number();
			android_codename = Build.VERSION.CODENAME;
			sdk_level = Build.VERSION.SDK;
			sdk_int = Build.VERSION.SDK_INT;
		}
		catch(Exception e)
		{
			Log.d("ex123","Error : "+e.getMessage());
		}
	}
}
