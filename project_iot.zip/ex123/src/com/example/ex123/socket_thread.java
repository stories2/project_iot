package com.example.ex123;

import java.net.Socket;

import android.util.Log;

public class socket_thread extends Thread{

	Socket socket;
	String hostname;
	int port,query_counter,query_exe_counter;
	public static boolean running;
	
	public socket_thread(int port_number)
	{
		try
		{
			query_counter = 0;
			query_exe_counter = 0;
			running = true;
			port = port_number;
			hostname = "223.194.115.119";
			Log.d("ex123","socket ip : "+hostname+":"+port);
		}
		catch(Exception e)
		{
			Log.d("ex123","Error : <Socket init> "+e.getMessage());
		}
	}
	
	public void run()
	{
		try
		{
			socket = new Socket(hostname,port);
			Log.d("ex123","connect");
		}
		catch(Exception e)
		{
			Log.d("ex123","Error <connection> "+e.getMessage());
		}
		while(running)
		{
			try
			{
				if(socket == null)
				{
					Log.d("ex123","Client <-> Server connection problem!");
					break;
				}
				if(MainTab.sql_query[query_exe_counter%MainTab.query_limit][1].equals("")!=true)
				{
					Log.d("ex123","Client <-> init : #"+query_exe_counter+MainTab.sql_query[query_exe_counter%MainTab.query_limit][1]);
					byte[] buffer_send = MainTab.sql_query[query_exe_counter%MainTab.query_limit][1].getBytes(), 
							buffer_receive = new byte[1200];
					socket.getOutputStream().write(buffer_send);
					socket.getOutputStream().flush();
					Log.d("ex123","Client -> Server : #"+query_exe_counter+MainTab.sql_query[query_exe_counter%MainTab.query_limit][1]);
					
					socket.getInputStream().read(buffer_receive);
					MainTab.sql_query[query_exe_counter%MainTab.query_limit][2] = new String(buffer_receive);
					Log.d("ex123","Client <- Server : #"+query_exe_counter+MainTab.sql_query[query_exe_counter%MainTab.query_limit][2]);
					
					query_exe_counter+=1;
				}
				Thread.sleep(1);
			}
			catch(Exception e)
			{
				running = false;
				Log.d("ex123","Error : <socket thread> "+e.getMessage());
			}
		}
		if(socket != null)
		{
			socket = null;
		}
		Log.d("ex123","socket thread closed");
	}

	public int execute_query(String string) {
		// TODO Auto-generated method stub
		MainTab.sql_query[query_counter%MainTab.query_limit][1] = string;
		query_counter += 1;
		return (query_counter-1)%MainTab.query_limit;
	}
}
