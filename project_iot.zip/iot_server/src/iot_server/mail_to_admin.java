package iot_server;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class mail_to_admin {

	String hostname = "smtp.gmail.com",
			user_id = "stories282@gmail.com",
			passwd = "go369369",
			receive_who = "stories282@gmail.com",
			subject = "",
			body = "";
	Properties properties;
	
	
	public mail_to_admin(String subject,String[] log,int size)
	{
		main_thread.loging.add_log("preparing to send mail size "+size, "mail_to_admin");
		
		this.subject = subject;
		this.body = "<html>"
					+"<head><meta charset='utf-8'></head>"
						+ "<body>"
							+ "<table border = '1'>";
		int i;
		for(i=0;i<size;i+=1)
		{
			this.body = this.body + log[i]; 
		}
		
		this.body = this.body + "</table></body></html>";
		try
		{
			String host = "smtp.gmail.com",
					username = "stories282@gmail.com",
					passwd = "go369369",
					receiver = "stories282@gmail.com";
			
			Properties properties = new Properties();
			properties.put("mail.smtps.auth",true);
			
			Session session = Session.getDefaultInstance(properties);
			MimeMessage msg = new MimeMessage(session);
			
			msg.setSubject(subject);
			msg.setText(body);
			msg.setFrom(new InternetAddress(username));
			msg.addRecipient(Message.RecipientType.TO, new InternetAddress(receiver));
			
			main_thread.loging.add_log("Mail is rdy", "mail_to_admin");
			Transport transport = session.getTransport("smtps");
			transport.connect(host,username,passwd);
			transport.sendMessage(msg,msg.getAllRecipients());
			transport.close();
			main_thread.loging.add_log("Mail Sended", "mail_to_admin");
		}
		catch(Exception e)
		{
			main_thread.loging.add_log("Error "+e.getMessage(), "mail_to_admin");
		}
		
	}
}
