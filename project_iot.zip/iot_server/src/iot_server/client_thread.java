package iot_server;

import java.net.Socket;
import java.util.Date;

public class client_thread extends Thread{

	Thread thread;
	Socket client_socket;
	int thread_number,motor_angle = 0,thread_various = 0; // 0 : normal , 1 : send to client only number , 2 : send to client only 0 1
	public static boolean running;
	byte[] buffer, read_write_buffer;
	String read_write,target_mac = "";
	
	public client_thread(Socket client_socket, int thread_number) {
		// TODO Auto-generated constructor stub
		try
		{
			this.client_socket = client_socket;
			this.thread_number = thread_number;
			running = true;
			
			main_thread.loging.add_log("TH#"+thread_number+" Started", "client_thread");
			thread = new Thread(this);
			thread.start();
		}
		catch(Exception e)
		{
			main_thread.loging.add_log("TH#"+thread_number+" init Error "+e.getMessage(), "client_thread");
		}
	}
	
	public String check_hangul(String target)
	{
		String result = "",first = "",second = "",third = "";
		int i,str_length,cnt = 0;
		char text;
		boolean read_hangul = false;
		str_length = target.length();
		for(i=0;i<str_length;i+=1)
		{
			text = target.charAt(i);
			if(read_hangul == true)
			{
				if(cnt == 1 && text != '&')
				{
					first = first + "" + text;
				}
				else if(cnt == 2 && text != '&')
				{
					second = second + "" + text;
				}
				else if(cnt == 3 && text != '&')
				{
					third = third + "" + text;
				}
			}
			else
			{
				if(text != '&')
				{
					result = result + "" + text;					
				}
			}
			if(text == '&')
			{
				cnt += 1;
				if(cnt<=3)
				{
					read_hangul = true;
				}
				else
				{
					try
					{
						char temp = (char) (0xAC00 + 28 * 21 * (Integer.parseInt(first)) + 28 * (Integer.parseInt(second)) + (Integer.parseInt(third)));
						first = "";
						second = "";
						third = "";
						result = result + "" + temp;
					}
					catch(Exception e)
					{
						main_thread.loging.add_log("TH#"+thread_number+" Error "+e.getMessage(), "client_thread");
						return "Sorry, we have bug, ask to Admin";
					}
					read_hangul = false;
					cnt = 0;
				}
			}
		}
		return result;
	}
	
	public void run()
	{
		int receive_size,i,queue_num;
		String temp = "nothing to show;";
		boolean r_flag = false;
		try
		{
			while(running)
			{
				try
				{
					if(client_socket!= null)
					{
						buffer = new byte[24576];
						receive_size = client_socket.getInputStream().read(buffer);
						if(receive_size > 0)
						{
							read_write_buffer = new byte[receive_size+1];
							for(i=0;i<receive_size;i+=1)
							{
								read_write_buffer[i] = buffer[i];
							}
							read_write = new String(read_write_buffer);
							main_thread.loging.add_log("TH#"+thread_number+" receive msg "+read_write+" size "+receive_size, "client_thread");
							
							if(read_write.contains("i am your father"))//�ʱ�ȭ ���ÿ� ���Ѻ� ����� ���ּҸ� ��
							{
								thread_various = 1;
								r_flag = true;
								
								int str_length = read_write.length();
								boolean write_mac = false;
								target_mac = "";
								for(i=0;i<str_length;i+=1)
								{
									if(read_write.charAt(i) == ';')
									{
										main_thread.loging.add_log("TH#"+thread_number+" Server will checking product_light : "+target_mac, "client_thread");
										break;
									}
									if(write_mac == true)
									{
										target_mac = target_mac + "" + read_write.charAt(i);
									}
									if(read_write.charAt(i) == '|')
									{
										if(write_mac == true)
										{
											write_mac = false;
										}
										else if(write_mac == false)
										{
											write_mac = true;
										}
									}
								}
							}
							else if(read_write.contains("nooooooo"))//��Ⱑ 0 �� 1���� ������ �� �ְԲ� ���� ������
							{
								thread_various = 2;
								temp = "1";
							}

							if(thread_various == 1)
							{
								if(r_flag == true)
								{
									r_flag = false;
									temp = "change angle to "+motor_angle+";";
								}
								else
								{
									motor_angle = parse_motor_return(read_write);//select Lux from product_light where ProductMac = 'target_mac';

									//������ ���� ��
									queue_num = main_thread.db.transfer_order("select Lux from product_light where ProductMac = '"+target_mac+"'");
									while(true)
									{
										if(main_thread.db.queue_result[queue_num].equals("")!=true)
										{
											temp = main_thread.db.queue_result[queue_num];
											break;
										}
										Thread.sleep(1);
									}
									
									int str_length = temp.length(),now_lux = 0,sum = 0,data_num = 0;
									String lux_temp = "";
									for(i=0;i<str_length;i+=1)
									{
										if(temp.charAt(i) == '|')
										{
											break;
										}
										if('0'<=temp.charAt(i) && temp.charAt(i)<='9')
										{
											lux_temp = lux_temp + "" + temp.charAt(i);
										}
									}
									try
									{
										now_lux = Integer.parseInt(lux_temp);
									}
									catch(Exception e)
									{
										main_thread.loging.add_log("TH#"+thread_number+" Error "+e.getMessage(), "client_thread");
									}
									
									//���� ���� ����
									Date date = new Date();
									main_thread.db.transfer_order("insert into product_log value('"+date.getYear()+"-"+date.getMonth()+"-"+date.getDay()+" "+
									date.getHours()+":"+date.getMinutes()+":"+date.getSeconds()+"','"+target_mac+"','"+motor_angle+"',2,'','',"+now_lux+");");
									main_thread.db.transfer_order("update product_motor set "+motor_angle+" where ProductMac = '"+target_mac+"';");
									
									//�������� ���� ���� ���
									queue_num = main_thread.db.transfer_order("select Lux from product_log where ProductMac = '"+target_mac+"'");
									while(true)
									{
										if(main_thread.db.queue_result[queue_num].equals("")!=true)
										{
											temp = main_thread.db.queue_result[queue_num];
											break;
										}
										Thread.sleep(1);
									}
									str_length = temp.length();
									lux_temp = "";
									data_num = 0;
									sum = 0;
									double average = 0;
									boolean data_exist = false;
									for(i=0;i<str_length;i+=1)
									{
										if(temp.charAt(i) == ';')
										{
											average = (double)sum/data_num;
											main_thread.loging.add_log("TH#"+thread_number+" lux sum : "+sum+" lux data_num : "+data_num+" lux average : "+average+" thread_option : "+thread_various, "client_thread");
											break;
										}
										if(temp.charAt(i) == '|')
										{
											lux_temp = "";
											if(data_exist == true)
											{
												data_exist = false;
												data_num += 1;
												try
												{
													sum = sum + Integer.parseInt(lux_temp);
												}
												catch(Exception e)
												{
													main_thread.loging.add_log("TH#"+thread_number+" Error "+e.getMessage(), "client_thread");
												}
											}
										}
										if('0'<=temp.charAt(i) && temp.charAt(i)<='9')
										{
											data_exist = true;
											lux_temp = lux_temp + "" + temp.charAt(i);
										}
									}
									
									if(average>now_lux)
									{
										motor_angle = 0;
										temp = "angle = "+motor_angle+";";
										
									}
									else
									{
										motor_angle = 270;
										temp = "angle = "+motor_angle+";";
									}
								}
							}
							else
							{
								queue_num = main_thread.db.transfer_order(read_write);
								while(true)
								{
									if(main_thread.db.queue_result[queue_num].equals("")!=true)
									{
										temp = main_thread.db.queue_result[queue_num];
										break;
									}
									Thread.sleep(1);
								}
							}
							
							
							prepare_to_send(thread_various,temp);
							client_socket.getOutputStream().flush();
							main_thread.loging.add_log("TH#"+thread_number+" Server -> Client Sended"+" thread_option : "+thread_various, "client_thread");
							buffer[0] = 0;
						}
						else
						{
							running = false;
							main_thread.loging.add_log("TH#"+thread_number+" I can't connect to client. So, i will die"+" thread_option : "+thread_various, "client_thread");
							break;
						}
					}
					else
					{
						main_thread.loging.add_log("TH#"+thread_number+" maybe client is disconnected"+" thread_option : "+thread_various, "client_thread");
						running = false;
						break;
					}
					Thread.sleep(1);
				}
				catch(Exception e)
				{
					running = false;
					main_thread.loging.add_log("TH#"+thread_number+" Error "+e.getMessage(), "client_thread");
				}
			}
			main_thread.loging.add_log("TH#"+thread_number+" This Thread is dead", "client_thread");
		}
		catch(Exception e)
		{
			running = false;
			main_thread.loging.add_log("TH#"+thread_number+" Error "+e.getMessage(), "client_thread");
		}
	}
	
	private int parse_motor_return(String read_write2) {
		// TODO Auto-generated method stub
		int i,str_length = read_write2.length(),result;
		String integer_str = "";
		for(i=0;i<str_length;i+=1)
		{
			if(read_write2.charAt(i)==';')
			{
				break;
			}
			else if('0' <= read_write2.charAt(i) && read_write2.charAt(i) <= '9')
			{
				integer_str = integer_str + "" + read_write2.charAt(i);
			}
		}
		result = Integer.parseInt(integer_str);
		return result;
	}

	public void prepare_to_send(int this_thread_various,String temp)
	{
		try
		{
			if(this_thread_various == 0)
			{
				temp = check_hangul(temp);
			}
			else if(this_thread_various == 1)
			{
				
			}
			else if(this_thread_various == 2)
			{
				if(temp.contains("1"))
				{
					temp = "1";
				}
				else
				{
					temp = "0";
				}
			}
		
			main_thread.loging.add_log("TH#"+thread_number+" Result "+temp+" thread_option : "+thread_various, "client_thread");
			read_write_buffer = temp.getBytes();
			client_socket.getOutputStream().write(read_write_buffer);
			main_thread.loging.add_log("TH#"+thread_number+" Server -> Client Writing..."+" thread_option : "+thread_various, "client_thread");
		}
		catch(Exception e)
		{
			main_thread.loging.add_log("TH#"+thread_number+" prepare to send Error "+e.getMessage(), "client_thread");
		}
	}

}
