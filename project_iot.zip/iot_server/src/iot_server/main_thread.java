package iot_server;

import java.net.ServerSocket;
import java.net.Socket;

public class main_thread extends Thread{
	
	int port,thread_number;
	static main_thread thread;
	public static boolean running;
	String address,ver;
	public static sys_log loging;
	public static db_manager db;
	ServerSocket server_socket;
	Socket client_socket;
	client_thread client;
	
	public main_thread()
	{
		try
		{
			ver = "Ver.1.31";
			address = "127.0.0.1";//127.0.0.1
			port = 8080;
			thread_number = 0;
			db = new db_manager(address);
			
			System.setProperty("java.net.preferIPv4Stack" , "true");
			
			loging.add_log("init...ok\nServer Info\nMysql Address : "+address+"\n"+"Server Port : "+port+"\nLog Limit : "+
			loging.limit+"\n"+ver, "main_thread");
			running = true;
		}
		catch(Exception e)
		{
			running = false;
			loging.add_log("Error "+e.getMessage(), "main_thread");
		}
	}
	
	public void run()
	{
		try
		{
			server_socket = new ServerSocket(port);
			while(running)
			{
				try
				{
					if(server_socket== null )
					{
						loging.add_log("Error The server socket is null", "main_thread");
						break;
					}
					loging.add_log("Waiting Client","main_thread");
					if(running == false)
					{
						break;
					}
					client_socket = server_socket.accept();
					loging.add_log("Client Accepted","main_thread");
					thread_number += 1;
					client = new client_thread(client_socket, thread_number);
					Thread.sleep(1);
				}
				catch(Exception e)
				{
					loging.add_log("Error "+e.getMessage(), "main_thread");
				}
			}
			if(server_socket!=null)
			{
				server_socket = null;
			}
			client_thread.running = false;
			db_manager.running = false;
			running = false;
			loging.add_log("Server Shuting down", "main_thread");
			loging.force_mail();
		}
		catch(Exception e)
		{
			running = false;
			client_thread.running = false;
			db_manager.running = false;
			loging.add_log("Error "+e.getMessage(), "main_thread");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		loging = new sys_log();
		loging.add_log("Main Thread Started", "main_thread");
		
		thread = new main_thread();
		thread.start();
	}

}
