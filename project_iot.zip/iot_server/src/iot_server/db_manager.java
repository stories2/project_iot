package iot_server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.ResultSetMetaData;

public class db_manager extends Thread{

	String host;
	Connection connection;
	Statement statement ;
	Thread thread;
	public static boolean running ;
	int limit,r,f,i;
	String[] queue_order,queue_result;
	
	public db_manager(String host)
	{
		try
		{
			limit = 100;
			r = 0;
			f = 0;
			this.host = host;
			running = true;
			queue_order = new String[limit];
			queue_result = new String[limit];
			for(i=0;i<limit;i+=1)
			{
				queue_order[i] = "";
				queue_result[i] = "";
			}
			
			String driverName = "com.mysql.jdbc.Driver";
			Class.forName(driverName).newInstance();
			
			String db_url = "jdbc:mysql://"+host+":3306";
			
			connection = DriverManager.getConnection(db_url,"stories2","toortoor%^%");
			
			connection.close();
			
			thread = new Thread(this);
			thread.start();
			main_thread.loging.add_log("DB init Successfully", "db_manager");
		}
		catch(Exception e)
		{
			main_thread.running = false;
			running = false;
			client_thread.running = false;
			main_thread.loging.add_log("Error "+e.getMessage(), "db_manager");
		}
	}
	
	public void run()
	{
		try
		{
			String driverName = "com.mysql.jdbc.Driver";
			Class.forName(driverName).newInstance();
		
			String db_url = "jdbc:mysql://"+host+":3306/stories2";
		
			
		
			while(running)
			{
				if(r!=f)
				{
					connection = DriverManager.getConnection(db_url,"stories2","toortoor%^%");
					f+=1;
					parse_order(f%limit);
					connection.close();
				}
				Thread.sleep(1);
			}
		}
		catch(Exception e)
		{
			main_thread.loging.add_log("Error "+e.getMessage(), "db_manager");
		}
	}
	
	public void parse_order(int order_number)
	{
		try
		{
			main_thread.loging.add_log("order_number "+order_number+" "+queue_order[order_number], "db_manager");
			if(queue_order[order_number].contains("select") || queue_order[order_number].contains("show") || queue_order[order_number].contains("desc")
					|| queue_order[order_number].contains("SELECT") || queue_order[order_number].contains("SHOW") || queue_order[order_number].contains("DESC"))
			{
				main_thread.loging.add_log("select || show || desc","db_manager");
				try
				{
					int i,column;
					String temp = "";
					statement = connection.createStatement();
					ResultSet result = statement.executeQuery(queue_order[order_number]);
					/*java.sql.ResultSetMetaData result_data = result.getMetaData();
					column = result_data.getColumnCount();*/
					while(result.next())
					{
						for(i=1;;i+=1)
						{
							try
							{
								temp = temp + result.getString(i)+"|";
							}
							catch(Exception e)
							{
								break;
							}
						}
						temp = temp + ";";
					}
					if(temp.equals(""))
					{
						queue_result[order_number] = "nothing to show";
					}
					else
					{
						queue_result[order_number] = temp;
					}
					main_thread.loging.add_log("result : "+queue_result[order_number]+" #"+order_number, "db_manager");
				}
				catch(Exception e)
				{
					queue_result[order_number] = "Error "+e.getMessage();
					main_thread.loging.add_log("Error "+e.getMessage(), "db_manager");
				}
			}
			else if(queue_order[order_number].contains("use") || queue_order[order_number].contains("create") || 
					queue_order[order_number].contains("drop") || queue_order[order_number].contains("alter") ||
					queue_order[order_number].contains("insert") || queue_order[order_number].contains("update")|| 
					queue_order[order_number].contains("USE") || queue_order[order_number].contains("CREATE") || 
					queue_order[order_number].contains("DROP") || queue_order[order_number].contains("ALTER") ||
					queue_order[order_number].contains("INSERT") || queue_order[order_number].contains("UPDATE"))
			{
				statement = connection.createStatement();
				main_thread.loging.add_log("use || create || drop || alter || insert || update","db_manager");
				try
				{
					queue_result[order_number] = ""+statement.executeUpdate(queue_order[order_number]);
				}
				catch(Exception e)
				{
					queue_result[order_number] = "Error "+e.getMessage();
					main_thread.loging.add_log("Error "+e.getMessage(), "db_manager");
				}
			}
			else if(queue_order[order_number].contains("mail to me"))
			{
				queue_result[order_number] = "Yes sir";
				main_thread.loging.add_log("Admin said 'i need log'", "Admin");
				main_thread.loging.force_mail();
			}
			else
			{
				queue_result[order_number] = "Sql Query Error";
			}
		}
		catch(Exception e)
		{
			queue_result[order_number] = "MySql Server Error";
			main_thread.loging.add_log("Error "+e.getMessage(), "db_manager");
		}
	}
	
	public int add_order(String order)
	{
		r+=1;
		queue_result[r%limit] = "";
		queue_order[r%limit] = order; 
		return r%limit;
	}
	
	public int transfer_order(String order)
	{/*
		String result = "";
		int check_point;
		check_point = add_order(order);
		main_thread.loging.add_log(order+" #"+check_point, "db_manager");
		queue_result[check_point] = "";
		while(true)
		{
			main_thread.loging.add_log("#"+check_point+" "+queue_result[check_point], "db_manager");
			//System.out.println("waiting response at "+check_point);
			if(queue_result[check_point].equals("")!=true)
			{
				main_thread.loging.add_log("#"+check_point+" result sended", "db_manager");
				result = queue_result[check_point];
				break;
			}
		}
		return result;*/
		int return_point = 0,i,str_length;
		String real_order = "";
		char temp;
		boolean hangul_found = false;
		
		r+=1;
		queue_result[r%limit] = "";
		str_length = order.length();
		for(i=0;i<str_length;i+=1)
		{
			temp = order.charAt(i);
			if(temp >= 44032 && temp <= 55215)
			{
				hangul_found = true;
				real_order = real_order + "&";
				real_order = real_order + "" + ((((temp - 0xAC00) - (temp - 0xAC00) % 28 ) ) / 28 ) / 21;
				real_order = real_order + "&";
				real_order = real_order + "" + ((((temp - 0xAC00) - (temp - 0xAC00) % 28 ) ) / 28 ) % 21;
				real_order = real_order + "&";
				real_order = real_order + "" + (temp - 0xAC00) % 28;
				real_order = real_order + "&";
			}
			else
			{
				real_order = real_order + "" + temp;
			}
		}
		queue_order[r%limit] = real_order; 
		return_point = r%limit;
		main_thread.loging.add_log("#"+return_point+" the query is in queue <"+(r%limit)+"/"+f+"> "+queue_order[r%limit]+" option -hangul "+hangul_found, "db_manager");
		
		return return_point;
	}
}
