package iot_server;

import java.util.Date;

public class sys_log {

	Date date;
	int top , limit;
	String[] log ; 
			
	public sys_log()
	{
		int i;
		limit = 1000;
		top = 0;
		log = new String[limit];
		for(i=0;i<limit;i+=1)
		{
			log[i] = "";
		}
		add_log("Loging System Started","sys_log");
	}
	
	public void add_log(String msg,String class_name)
	{
		date = new Date();
		top += 1;
		log[top % limit] = "<tr><td>"+(date.getYear()-100)+"."+(date.getMonth()+1)+"."+date.getDate()+"/"+date.getHours()+
				":"+date.getMinutes()+":"+date.getSeconds()+"</td><td>"+class_name+"</td><td>"+msg+"</td></tr>";
		System.out.println("#"+top+" "+(date.getYear()-100)+"."+(date.getMonth()+1)+"."+date.getDate()+"/"+date.getHours()+
				":"+date.getMinutes()+":"+date.getSeconds()+"://"+class_name+"/"+msg);
		
		if(top % limit == limit - 1)
		{
			mail_to_admin mail = new mail_to_admin("Iot Server Log",log,limit);
		}
	}
	
	public void force_mail()
	{
		mail_to_admin mail = new mail_to_admin("Iot Server Log",log,top % limit);
	}
}
